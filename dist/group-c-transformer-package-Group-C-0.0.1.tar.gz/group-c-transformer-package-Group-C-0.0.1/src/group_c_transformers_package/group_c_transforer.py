def scan(X):
   """This is the scan method for group c transformer""" 
   print("this is the scan method")

def fit(X,y):
   """This is the scan method for group c transformer""" 
   print("this is the fit method")

def transform(X):
   """This is the transform method for group c transformer""" 
   print("this is the transform method")

