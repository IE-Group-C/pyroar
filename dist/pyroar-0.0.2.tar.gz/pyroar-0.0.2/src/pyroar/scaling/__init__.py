# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 12:20:23 2022

@author: fagfa
"""

from .scaling import Scaler
operator_dic = {
    "scaling": Scaler
}
