# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 12:20:23 2022

@author: fagfa
"""

from .transformation import Transformer
operator_dic = {
    "transformation": Transformer
}
