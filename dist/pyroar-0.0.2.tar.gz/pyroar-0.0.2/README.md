# pyroar Transofrmation Package
When Py roars, it produces such powerful package
This package scans any pandas datafram and gives recommendation about the required data engineering and data wrangling for the data using statistical methods
You can performs the follwoing:
- Missing Values treatment (dropping and imputation)
- Outliers detection (using Tuckey Inter Quartile Range (IQR), z-score test for normaly distributed data and skewed data)
- Feature transformations ( reciprocal, squared, and log)
- Scaling for Normal and Noraml Distribuated Featrures.
- Statistical testing using Shapiro and Jaque-bera for numerical features
- Statistical testing using Chai-square for categorical features.
- Recommendation for re-grouping classes of categorical variables 

The following features will be implemented in the future realeases:
- Grouping and binning using statistical testing for ordinal features
- Statistical testing for numerical variables (poission test)
. The source code is available at 
[Github-flavored Markdown](https://github.com/IE-Group-C/pyroar.git)
.